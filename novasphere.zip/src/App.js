import React from "react";

function Card({ title, children }) {
  return (
    <div style={{ background: '#1f2937', padding: '1.5rem', borderRadius: '1rem', color: '#fff' }}>
      <h2 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '0.5rem' }}>{title}</h2>
      <p style={{ color: '#ccc' }}>{children}</p>
    </div>
  );
}

export default function App() {
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(to bottom right, #111827, #000)', color: '#fff', padding: '2rem' }}>
      <header style={{ textAlign: 'center', padding: '2rem 0' }}>
        <h1 style={{ fontSize: '3rem', fontWeight: '700' }}>NovaSphere</h1>
        <p style={{ fontSize: '1.125rem', marginTop: '0.5rem', color: '#9ca3af' }}>Innovating the Digital World</p>
      </header>

      <div style={{ display: 'grid', gap: '1.5rem', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', maxWidth: '1000px', margin: '0 auto' }}>
        <Card title="Fast & Secure">Experience blazing-fast performance and top-level security across all platforms.</Card>
        <Card title="Modern Design">Sleek and intuitive interface with a focus on user experience and responsiveness.</Card>
        <Card title="Reliable Hosting">Deployed on global infrastructure ensuring 99.99% uptime and fast delivery.</Card>
      </div>

      <footer style={{ textAlign: 'center', marginTop: '4rem', color: '#6b7280', fontSize: '0.875rem' }}>
        © 2025 NovaSphere. All rights reserved.
      </footer>
    </div>
  );
}